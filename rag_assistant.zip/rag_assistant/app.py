"""
Smart Research Assistant — Streamlit UI
=========================================
End-to-end RAG app: upload documents -> ask questions -> get grounded
answers with source citations and RAGAs reliability scores.

Run with:  streamlit run app.py
"""
import os
import sys
import tempfile

import streamlit as st

sys.path.append(os.path.dirname(__file__))

from src.config import settings
from src.ingestion import ingest_files, ingest_url
from src.vectorstore import (
    build_vectorstore,
    load_vectorstore,
    add_to_vectorstore,
    get_retriever,
)
from src.rag_chain import answer_query
from src.evaluation import evaluate_answer

st.set_page_config(page_title="Smart Research Assistant", page_icon="📚", layout="wide")

# ---------------------------------------------------------------------------
# Session state
# ---------------------------------------------------------------------------
if "vectorstore" not in st.session_state:
    st.session_state.vectorstore = load_vectorstore()
if "chat_history" not in st.session_state:
    st.session_state.chat_history = []  # list of (question, answer)
if "last_result" not in st.session_state:
    st.session_state.last_result = None

# ---------------------------------------------------------------------------
# Sidebar — ingestion controls
# ---------------------------------------------------------------------------
with st.sidebar:
    st.header("📁 Document Ingestion")
    st.caption(
        f"Embeddings: **{settings.embedding_provider}** | "
        f"LLM: **{settings.llm_provider}** | "
        f"Vector store: **{settings.vectorstore_backend}**"
    )

    uploaded_files = st.file_uploader(
        "Upload PDF / TXT / DOCX documents",
        type=["pdf", "txt", "docx", "md"],
        accept_multiple_files=True,
    )
    url_input = st.text_input("...or paste a web page URL")

    col_a, col_b = st.columns(2)
    with col_a:
        build_clicked = st.button("Build / Rebuild Index", type="primary", use_container_width=True)
    with col_b:
        add_clicked = st.button("Add to Index", use_container_width=True)

    if build_clicked or add_clicked:
        with st.spinner("Processing documents..."):
            chunks = []
            if uploaded_files:
                saved_paths = []
                for f in uploaded_files:
                    path = os.path.join(settings.upload_dir, f.name)
                    with open(path, "wb") as out:
                        out.write(f.getbuffer())
                    saved_paths.append(path)
                chunks.extend(ingest_files(saved_paths))
            if url_input:
                chunks.extend(ingest_url(url_input))

            if not chunks:
                st.warning("Upload a file or provide a URL first.")
            else:
                if build_clicked or st.session_state.vectorstore is None:
                    st.session_state.vectorstore = build_vectorstore(chunks)
                else:
                    st.session_state.vectorstore = add_to_vectorstore(
                        st.session_state.vectorstore, chunks
                    )
                st.success(f"Indexed {len(chunks)} chunks.")

    st.divider()
    if st.session_state.vectorstore is not None:
        st.success("✅ Vector index ready")
    else:
        st.info("No index yet — upload documents to get started.")

    if st.button("🗑️ Clear conversation"):
        st.session_state.chat_history = []
        st.session_state.last_result = None
        st.rerun()

# ---------------------------------------------------------------------------
# Main panel — chat interface
# ---------------------------------------------------------------------------
st.title("📚 Smart Research Assistant")
st.caption("Ask questions about your uploaded documents. Answers are grounded in retrieved context.")

for q, a in st.session_state.chat_history:
    with st.chat_message("user"):
        st.write(q)
    with st.chat_message("assistant"):
        st.write(a)

question = st.chat_input("Ask a question about your documents...")

if question:
    if st.session_state.vectorstore is None:
        st.error("Please upload and index at least one document first (see sidebar).")
    else:
        with st.chat_message("user"):
            st.write(question)

        with st.chat_message("assistant"):
            with st.spinner("Retrieving context and generating answer..."):
                retriever = get_retriever(st.session_state.vectorstore)
                result = answer_query(
                    retriever, question, history=st.session_state.chat_history
                )
            st.write(result["answer"])
            st.session_state.last_result = result

        st.session_state.chat_history.append((question, result["answer"]))

# ---------------------------------------------------------------------------
# Source context + evaluation for the most recent answer
# ---------------------------------------------------------------------------
if st.session_state.last_result:
    result = st.session_state.last_result
    st.divider()
    col1, col2 = st.columns([3, 2])

    with col1:
        st.subheader("📄 Supporting document context")
        for i, doc in enumerate(result["source_documents"], start=1):
            with st.expander(f"Chunk {i} — {doc.metadata.get('source', 'unknown')}"):
                st.write(doc.page_content)

    with col2:
        st.subheader("📊 Reliability evaluation (RAGAs)")
        if st.button("Run evaluation on last answer"):
            with st.spinner("Scoring faithfulness, relevancy, and context precision..."):
                contexts = [d.page_content for d in result["source_documents"]]
                scores = evaluate_answer(result["question"], result["answer"], contexts)
            if "error" in scores:
                st.warning(f"Evaluation unavailable: {scores['error']}")
            else:
                m1, m2, m3 = st.columns(3)
                m1.metric("Faithfulness", scores["faithfulness"])
                m2.metric("Answer Relevancy", scores["answer_relevancy"])
                m3.metric("Context Precision", scores["context_precision"])
