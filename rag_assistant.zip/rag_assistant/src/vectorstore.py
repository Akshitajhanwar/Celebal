"""
Storage Stage (Step 2 of the RAG pipeline).

Wraps embedding-model selection and vector-store creation so the rest of
the app doesn't care whether we're using OpenAI or Hugging Face embeddings,
or FAISS vs. ChromaDB for storage.
"""
import os
import shutil
from typing import List

from langchain_core.documents import Document
from langchain_core.embeddings import Embeddings
from langchain_community.vectorstores import FAISS, Chroma

from src.config import settings


def get_embedding_model() -> Embeddings:
    """Return an embeddings object based on EMBEDDING_PROVIDER."""
    if settings.embedding_provider == "openai":
        from langchain_openai import OpenAIEmbeddings

        if not settings.openai_api_key:
            raise ValueError(
                "EMBEDDING_PROVIDER=openai but OPENAI_API_KEY is not set."
            )
        return OpenAIEmbeddings(
            model=settings.openai_embedding_model,
            api_key=settings.openai_api_key,
        )

    # Default: local, free, offline-capable Hugging Face embeddings
    from langchain_huggingface import HuggingFaceEmbeddings

    return HuggingFaceEmbeddings(model_name=settings.hf_embedding_model)


def build_vectorstore(chunks: List[Document], persist: bool = True):
    """
    Embed `chunks` and build a new vector store, overwriting any existing
    persisted store. Returns the vector store object.
    """
    embeddings = get_embedding_model()

    if settings.vectorstore_backend == "chroma":
        persist_dir = os.path.join(settings.vectorstore_dir, "chroma")
        if persist and os.path.exists(persist_dir):
            shutil.rmtree(persist_dir)
        vs = Chroma.from_documents(
            chunks, embeddings, persist_directory=persist_dir if persist else None
        )
        return vs

    # Default: FAISS
    vs = FAISS.from_documents(chunks, embeddings)
    if persist:
        vs.save_local(os.path.join(settings.vectorstore_dir, "faiss_index"))
    return vs


def load_vectorstore():
    """Load a previously persisted vector store. Returns None if none exists."""
    embeddings = get_embedding_model()

    if settings.vectorstore_backend == "chroma":
        persist_dir = os.path.join(settings.vectorstore_dir, "chroma")
        if not os.path.exists(persist_dir):
            return None
        return Chroma(persist_directory=persist_dir, embedding_function=embeddings)

    faiss_path = os.path.join(settings.vectorstore_dir, "faiss_index")
    if not os.path.exists(faiss_path):
        return None
    return FAISS.load_local(
        faiss_path, embeddings, allow_dangerous_deserialization=True
    )


def add_to_vectorstore(vs, chunks: List[Document], persist: bool = True):
    """Add new chunks to an existing vector store (incremental ingestion)."""
    vs.add_documents(chunks)
    if persist and settings.vectorstore_backend == "faiss":
        vs.save_local(os.path.join(settings.vectorstore_dir, "faiss_index"))
    return vs


def get_retriever(vs, top_k: int = None):
    """Return a retriever configured for top-k similarity search."""
    return vs.as_retriever(search_kwargs={"k": top_k or settings.top_k})
