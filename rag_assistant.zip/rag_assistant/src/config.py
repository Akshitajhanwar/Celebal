"""
Central configuration for the Smart Research Assistant (RAG system).

All settings are read from environment variables (loaded from a .env file
via python-dotenv) so the same codebase can flip between providers
(OpenAI <-> Hugging Face, FAISS <-> ChromaDB) without touching code.
"""
import os
from dataclasses import dataclass
from dotenv import load_dotenv

load_dotenv()


@dataclass(frozen=True)
class Settings:
    # --- Providers ---
    embedding_provider: str = os.getenv("EMBEDDING_PROVIDER", "huggingface").lower()
    llm_provider: str = os.getenv("LLM_PROVIDER", "openai").lower()
    vectorstore_backend: str = os.getenv("VECTORSTORE_BACKEND", "faiss").lower()

    # --- API keys ---
    openai_api_key: str = os.getenv("OPENAI_API_KEY", "")
    hf_token: str = os.getenv("HUGGINGFACEHUB_API_TOKEN", "")

    # --- Chunking ---
    chunk_size: int = int(os.getenv("CHUNK_SIZE", 1000))
    chunk_overlap: int = int(os.getenv("CHUNK_OVERLAP", 150))

    # --- Retrieval ---
    top_k: int = int(os.getenv("TOP_K", 4))

    # --- Models ---
    openai_embedding_model: str = "text-embedding-3-small"
    hf_embedding_model: str = "sentence-transformers/all-MiniLM-L6-v2"
    openai_llm_model: str = "gpt-4o-mini"

    # --- Paths ---
    upload_dir: str = os.path.join(os.path.dirname(__file__), "..", "data", "uploads")
    vectorstore_dir: str = os.path.join(os.path.dirname(__file__), "..", "data", "vectorstore")


settings = Settings()

os.makedirs(settings.upload_dir, exist_ok=True)
os.makedirs(settings.vectorstore_dir, exist_ok=True)
