"""
Data Ingestion Stage (Step 1 of the RAG pipeline).

Responsibilities:
    1. Load raw documents (PDF, TXT, DOCX, or a web URL).
    2. Split them into overlapping chunks sized for embedding + retrieval.

Each chunk keeps metadata (source filename / URL, page number where
available) so answers can later be traced back to their source.
"""
import os
from typing import List

from langchain_community.document_loaders import (
    PyPDFLoader,
    TextLoader,
    Docx2txtLoader,
    WebBaseLoader,
)
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_core.documents import Document

from src.config import settings

SUPPORTED_EXTENSIONS = {".pdf", ".txt", ".docx", ".md"}


def load_document(file_path: str) -> List[Document]:
    """Load a single local file into LangChain Document objects."""
    ext = os.path.splitext(file_path)[1].lower()

    if ext == ".pdf":
        loader = PyPDFLoader(file_path)
    elif ext in {".txt", ".md"}:
        loader = TextLoader(file_path, encoding="utf-8")
    elif ext == ".docx":
        loader = Docx2txtLoader(file_path)
    else:
        raise ValueError(
            f"Unsupported file type '{ext}'. Supported: {SUPPORTED_EXTENSIONS}"
        )

    docs = loader.load()
    for d in docs:
        d.metadata["source"] = os.path.basename(file_path)
    return docs


def load_web_page(url: str) -> List[Document]:
    """Load and return the text content of a web page as Documents."""
    loader = WebBaseLoader(url)
    docs = loader.load()
    for d in docs:
        d.metadata["source"] = url
    return docs


def chunk_documents(
    documents: List[Document],
    chunk_size: int = None,
    chunk_overlap: int = None,
) -> List[Document]:
    """Split documents into overlapping chunks suitable for embedding."""
    splitter = RecursiveCharacterTextSplitter(
        chunk_size=chunk_size or settings.chunk_size,
        chunk_overlap=chunk_overlap or settings.chunk_overlap,
        separators=["\n\n", "\n", ". ", " ", ""],
    )
    chunks = splitter.split_documents(documents)

    # Give each chunk a stable id for later citation / evaluation
    for i, chunk in enumerate(chunks):
        chunk.metadata["chunk_id"] = i
    return chunks


def ingest_files(file_paths: List[str]) -> List[Document]:
    """Load + chunk a batch of local files in one call."""
    all_docs: List[Document] = []
    for path in file_paths:
        all_docs.extend(load_document(path))
    return chunk_documents(all_docs)


def ingest_url(url: str) -> List[Document]:
    """Load + chunk a single web page."""
    return chunk_documents(load_web_page(url))
