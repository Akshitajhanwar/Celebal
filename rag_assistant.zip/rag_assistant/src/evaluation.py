"""
Evaluation Stage (Step 5 of the RAG pipeline).

Uses the RAGAs framework to score each answer on:
    - Faithfulness        -> is the answer grounded in the retrieved context?
    - Answer Relevancy    -> does the answer actually address the question?
    - Context Precision   -> how relevant/precise was the retrieved context?

These scores are what let the UI show a "reliability" indicator next to
every generated answer, per the project brief.
"""
from typing import Dict, List

from datasets import Dataset

from src.config import settings


def _get_ragas_llm_and_embeddings():
    """RAGAs needs its own LLM + embeddings to act as the 'judge'."""
    from langchain_openai import ChatOpenAI, OpenAIEmbeddings

    if not settings.openai_api_key:
        raise ValueError(
            "RAGAs evaluation currently requires OPENAI_API_KEY to be set "
            "(used as the judge model)."
        )
    llm = ChatOpenAI(model=settings.openai_llm_model, temperature=0, api_key=settings.openai_api_key)
    embeddings = OpenAIEmbeddings(model=settings.openai_embedding_model, api_key=settings.openai_api_key)
    return llm, embeddings


def evaluate_answer(
    question: str,
    answer: str,
    contexts: List[str],
) -> Dict[str, float]:
    """
    Score a single Q/A pair. Returns a dict of metric_name -> score (0-1).
    Falls back to a clear error message in the score dict if evaluation
    cannot run (e.g. no OpenAI key configured).
    """
    try:
        from ragas import evaluate
        from ragas.metrics import faithfulness, answer_relevancy, context_precision

        llm, embeddings = _get_ragas_llm_and_embeddings()

        dataset = Dataset.from_dict(
            {
                "question": [question],
                "answer": [answer],
                "contexts": [contexts],
            }
        )

        result = evaluate(
            dataset,
            metrics=[faithfulness, answer_relevancy, context_precision],
            llm=llm,
            embeddings=embeddings,
        )
        df = result.to_pandas()
        return {
            "faithfulness": round(float(df["faithfulness"].iloc[0]), 3),
            "answer_relevancy": round(float(df["answer_relevancy"].iloc[0]), 3),
            "context_precision": round(float(df["context_precision"].iloc[0]), 3),
        }
    except Exception as e:  # pragma: no cover - surfaced to UI instead of raised
        return {"error": str(e)}


def batch_evaluate(qa_pairs: List[Dict]) -> "list[dict]":
    """
    Evaluate a list of {question, answer, contexts} dicts at once.
    More efficient than calling evaluate_answer() in a loop for many pairs.
    """
    from ragas import evaluate
    from ragas.metrics import faithfulness, answer_relevancy, context_precision

    llm, embeddings = _get_ragas_llm_and_embeddings()

    dataset = Dataset.from_dict(
        {
            "question": [p["question"] for p in qa_pairs],
            "answer": [p["answer"] for p in qa_pairs],
            "contexts": [p["contexts"] for p in qa_pairs],
        }
    )
    result = evaluate(
        dataset,
        metrics=[faithfulness, answer_relevancy, context_precision],
        llm=llm,
        embeddings=embeddings,
    )
    return result.to_pandas().to_dict(orient="records")
