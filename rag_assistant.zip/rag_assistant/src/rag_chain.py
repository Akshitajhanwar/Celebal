"""
Query Processing + Answer Generation Stage (Steps 3 & 4 of the RAG pipeline).

Builds a retrieval chain that:
    1. Embeds the user's query (implicitly, via the retriever).
    2. Fetches the top-k most relevant chunks from the vector store.
    3. Feeds (query + retrieved context) into an LLM.
    4. Returns an answer grounded in the retrieved context, plus the
       source chunks used, plus running conversational memory.
"""
from typing import Dict, List, Tuple

from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser
from langchain_core.runnables import RunnablePassthrough
from langchain_core.documents import Document

from src.config import settings

SYSTEM_PROMPT = """You are a careful research assistant. Answer the user's \
question using ONLY the information in the provided context.

Rules:
- If the answer is not contained in the context, say clearly that the \
documents don't contain enough information — do not make anything up.
- Be precise and concise.
- When useful, refer to the source document by name.

Context:
{context}

Conversation history (may be empty):
{history}
"""

PROMPT = ChatPromptTemplate.from_messages(
    [
        ("system", SYSTEM_PROMPT),
        ("human", "{question}"),
    ]
)


def get_llm():
    """Return a chat LLM based on LLM_PROVIDER."""
    if settings.llm_provider == "huggingface":
        from langchain_huggingface import HuggingFaceEndpoint, ChatHuggingFace

        endpoint = HuggingFaceEndpoint(
            repo_id="mistralai/Mistral-7B-Instruct-v0.2",
            huggingfacehub_api_token=settings.hf_token,
            temperature=0.2,
            max_new_tokens=512,
        )
        return ChatHuggingFace(llm=endpoint)

    from langchain_openai import ChatOpenAI

    if not settings.openai_api_key:
        raise ValueError("LLM_PROVIDER=openai but OPENAI_API_KEY is not set.")
    return ChatOpenAI(
        model=settings.openai_llm_model,
        temperature=0.2,
        api_key=settings.openai_api_key,
    )


def _format_docs(docs: List[Document]) -> str:
    return "\n\n".join(
        f"[Source: {d.metadata.get('source', 'unknown')} | "
        f"chunk {d.metadata.get('chunk_id', '?')}]\n{d.page_content}"
        for d in docs
    )


def _format_history(history: List[Tuple[str, str]]) -> str:
    if not history:
        return "(no prior turns)"
    return "\n".join(f"User: {q}\nAssistant: {a}" for q, a in history)


def answer_query(
    retriever,
    question: str,
    history: List[Tuple[str, str]] = None,
) -> Dict:
    """
    Run the full retrieve -> generate flow for a single question.

    Returns a dict with: answer, source_documents, question.
    """
    history = history or []

    retrieved_docs = retriever.invoke(question)
    llm = get_llm()

    chain = (
        {
            "context": lambda x: _format_docs(retrieved_docs),
            "history": lambda x: _format_history(history),
            "question": RunnablePassthrough(),
        }
        | PROMPT
        | llm
        | StrOutputParser()
    )

    answer = chain.invoke(question)

    return {
        "question": question,
        "answer": answer,
        "source_documents": retrieved_docs,
    }
