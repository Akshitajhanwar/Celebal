# 📚 Smart Research Assistant (RAG-Based Knowledge System)

An end-to-end Retrieval-Augmented Generation (RAG) assistant that lets you
upload documents (PDF, TXT, DOCX, or web pages) and ask natural-language
questions about them. Answers are grounded in retrieved source chunks and
scored for reliability using RAGAs metrics.

Built to mirror the standard RAG pipeline used in production systems:

```
User Query -> Embed Query -> Retrieve Chunks (vector DB) -> LLM Generation -> Grounded Answer + Eval Score
```

## Architecture

```
┌─────────────┐     ┌──────────────┐     ┌───────────────┐     ┌─────────────┐
│  Ingestion  │ --> │   Storage    │ --> │    Query +    │ --> │ Evaluation  │
│ (load/chunk)│     │(FAISS/Chroma)│     │  Generation   │     │  (RAGAs)    │
└─────────────┘     └──────────────┘     └───────────────┘     └─────────────┘
       |                    |                     |                    |
  src/ingestion.py   src/vectorstore.py     src/rag_chain.py    src/evaluation.py
```

All of it is wired together in `app.py`, a Streamlit chat UI.

## Project Structure

```
rag_assistant/
├── app.py                 # Streamlit UI (entry point)
├── requirements.txt
├── .env.example            # copy to .env and fill in
├── src/
│   ├── config.py           # central settings, provider switches
│   ├── ingestion.py        # Step 1: load + chunk documents
│   ├── vectorstore.py      # Step 2: embeddings + FAISS/ChromaDB storage
│   ├── rag_chain.py        # Steps 3-4: retrieval + LLM answer generation
│   └── evaluation.py       # Step 5: RAGAs faithfulness/relevancy/precision
└── data/
    ├── uploads/             # uploaded source files land here
    └── vectorstore/         # persisted FAISS index / Chroma DB
```

## Setup

```bash
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt

cp .env.example .env
# edit .env: set OPENAI_API_KEY if using OpenAI for embeddings/LLM
```

### Provider switches (in `.env`)

| Variable              | Options                 | Default        |
|-----------------------|--------------------------|----------------|
| `EMBEDDING_PROVIDER`  | `huggingface` \| `openai` | `huggingface` (free, local, no key needed) |
| `LLM_PROVIDER`        | `openai` \| `huggingface` | `openai`       |
| `VECTORSTORE_BACKEND` | `faiss` \| `chroma`       | `faiss`        |

This means you can run the whole thing **for free/offline** with
`EMBEDDING_PROVIDER=huggingface`, and only need an OpenAI key for the LLM
generation step (or swap that to Hugging Face too).

## Run

```bash
streamlit run app.py
```

Then in the browser:
1. Upload one or more documents (or paste a URL) in the sidebar.
2. Click **Build / Rebuild Index** (or **Add to Index** to append more docs later).
3. Ask a question in the chat box, e.g. *"What is the leave policy?"*
4. Expand **Supporting document context** to see the exact chunks used.
5. Click **Run evaluation on last answer** to see Faithfulness / Answer
   Relevancy / Context Precision scores (requires `OPENAI_API_KEY` — RAGAs
   uses an LLM as judge).

## How each pipeline stage maps to code

| Step | Description | Module |
|------|-------------|--------|
| 1. Data Ingestion | Load PDFs/TXT/DOCX/web pages, split into overlapping chunks | `src/ingestion.py` |
| 2. Storage | Embed chunks, persist to FAISS or ChromaDB | `src/vectorstore.py` |
| 3. Query Processing | Embed user query, retrieve top-k relevant chunks | `src/vectorstore.py::get_retriever` |
| 4. Answer Generation | Combine query + context, prompt the LLM | `src/rag_chain.py` |
| 5. Evaluation | Score faithfulness / relevancy / context precision | `src/evaluation.py` |

## Extending this project (matches "Future Enhancements" in the brief)

- **Multi-turn memory**: already implemented — `chat_history` is passed
  into the prompt on every turn (see `app.py` + `rag_chain.py`).
- **Switch vector DB at runtime**: change `VECTORSTORE_BACKEND` in `.env`.
- **Voice interaction**: add `speech_recognition` for input and a TTS
  library (e.g. `pyttsx3`) for output around the existing `answer_query()` call.
- **Cloud deployment**: containerize with Docker, deploy Streamlit app to
  AWS ECS / GCP Cloud Run; swap FAISS for a managed vector DB (e.g.
  Pinecone, pgvector) by adding a new branch in `vectorstore.py`.
- **Domain-specific assistants**: swap the `SYSTEM_PROMPT` in
  `rag_chain.py` per domain (legal, healthcare, finance) and point
  ingestion at a domain-specific document set.
- **Auth for enterprise use**: add `streamlit-authenticator` in front of
  `app.py`.

## Notes for interns

- Start by reading `src/ingestion.py` -> `src/vectorstore.py` ->
  `src/rag_chain.py` -> `src/evaluation.py` in that order — it's the same
  order data flows through the system.
- `EMBEDDING_PROVIDER=huggingface` lets you run everything without any
  API key except for the final answer-generation LLM call, which is a
  good way to understand the retrieval half of RAG before paying for LLM calls.
- Try breaking the system: ask a question with no relevant documents
  uploaded, and see how the prompt in `rag_chain.py` is designed to make
  the LLM say "I don't know" instead of hallucinating.
